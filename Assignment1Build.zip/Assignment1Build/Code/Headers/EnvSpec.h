#define USING_WINDOWS
//#define USING_LINUX

//#define DEBUG
